create procedure insert_history(IN book_id int, IN reader_id int)
  BEGIN
    DECLARE msg varchar(40);

    IF NOT EXISTS(SELECT * FROM book WHERE id = book_id)
      THEN SET msg = 'THIS BOOK IS ABSCENT';
    ELSEIF NOT EXISTS (SELECT * FROM reader WHERE id = reader_id)
      THEN SET msg = 'THIS READER IS ABSCENT';
    ELSEIF NOT EXISTS(SELECT * FROM book WHERE id = book_id AND availability = 1)
      THEN SET msg = 'THIS BOOK IS OUT OF STOCK';

    ELSE
      INSERT history (book, reader) VALUE ((SELECT id FROM book WHERE id = book_id),
                                           (SELECT id FROM reader WHERE id = reader_id));
      SET msg = 'OK';

    END IF;
    SELECT msg as msg;
  END;

