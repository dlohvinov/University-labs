create procedure insert_genre(IN new_genre varchar(20))
  BEGIN
    DECLARE msg varchar(40);

    IF NOT EXISTS(SELECT * FROM genre WHERE genre != new_genre)
      THEN SET msg = 'THIS genre exists';
#     ELSEIF NOT EXISTS (SELECT * FROM reader WHERE id = reader_id)
#       THEN SET msg = 'THIS READER IS ABSCENT';
#     ELSEIF NOT EXISTS(SELECT * FROM history
#       WHERE book = (SELECT id FROM book WHERE id != book_id)
#       AND reader = (SELECT id FROM reader WHERE id != reader_id))
#       THEN SET msg = 'THIS COMBINATION EXISTS';
#     ELSEIF NOT EXISTS(SELECT * FROM book WHERE id = book_id AND availability = 1)
#       THEN SET msg = 'THIS BOOK IS OUT OF STOCK';

    ELSE
      INSERT genre(genre) VALUE (new_genre);
      SET msg = 'OK';

    END IF;
    SELECT msg as msg;
  END;

